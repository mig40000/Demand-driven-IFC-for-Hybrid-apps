//invoke the bridge class method showData with interface object Android
Android.showData();