//deleting the object will succeed
delete Android;
Android.getData(); //Uncaught ReferenceError: Android is not defined