package com.example.strongupdate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private String deviceLocation;
    protected LocationManager locationManager;
    protected LocationListener locationListener;

    private void setLocation() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
    }

    private void setDummyLocation(){
        this.deviceLocation = "dummyLocation";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setLocation();
    }

    public void loadWeb() {

        WebView myWebView = (WebView) findViewById(R.id.webview);
        WebSettings webSettings = myWebView.getSettings();
        Log.d("TaintedData", "came here  A");
        //enable the JavaScript
        webSettings.setJavaScriptEnabled(true);

        BridgeClass ifcObj = new BridgeClass();
        ifcObj.setLocation(this.deviceLocation);
        myWebView.addJavascriptInterface(ifcObj, "Android");

        myWebView.loadUrl("file:///android_asset/index.html");

        /* Case A: Update interface object after loading the web
            the interface object now contain dummy Location.
            The Web side will always have dummy location, i.e.,
            the update will always reflect in the shared JavaScript
         */
        this.setDummyLocation();
        ifcObj.setLocation(this.deviceLocation);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        Log.d("TaintedData", "inside onLocationChanged");
        this.deviceLocation =  "Latitude: " + location.getLatitude() + " Longitude: " + location.getLongitude();
        loadWeb();
    }


}