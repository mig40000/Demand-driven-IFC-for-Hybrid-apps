package com.example.strongupdate;

import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class BridgeClass {
    public String data;

    public void setLocation(String data){
        this.data = data;
    }

    @JavascriptInterface
    public void showData() {
        Log.d("TaintedData", "Data is " + this.data);
    }
}
