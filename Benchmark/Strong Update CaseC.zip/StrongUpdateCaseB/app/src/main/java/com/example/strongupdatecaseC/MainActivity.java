package com.example.strongupdatecaseC;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    private String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView myWebView = (WebView) findViewById(R.id.webview);
        WebSettings webSettings = myWebView.getSettings();

        //enable the JavaScript
        webSettings.setJavaScriptEnabled(true);

        MainActivity ifcObj = new MainActivity();
        ifcObj.setData("publicData");
        myWebView.addJavascriptInterface(ifcObj, "Android");

        myWebView.loadUrl("file:///android_asset/index.html");

        //sensitive data will be visible in shared JS even after main thread sleeps
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ifcObj.setData("sensitive");

    }


    public void setData(String sensitivity){
        this.data = sensitivity;
    }

    @JavascriptInterface
    public String getData(){
        Log.d("TaintedData", "extracted data is " + this.data);
        return this.data;
    }


}