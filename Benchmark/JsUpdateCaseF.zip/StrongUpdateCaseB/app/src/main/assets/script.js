//deleting the property will get ignored
delete Android.getData;
Android.getData();